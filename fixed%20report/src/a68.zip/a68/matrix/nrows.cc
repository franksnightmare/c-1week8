#include "matrix.ih"

size_t Matrix::nRows()
{
	return d_nRows;
}
