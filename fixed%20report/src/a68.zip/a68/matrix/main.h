#ifndef MAIN_H_
#define MAIN_H_

#include "matrix.h"

void printMatrix(Matrix matrix);

#endif
