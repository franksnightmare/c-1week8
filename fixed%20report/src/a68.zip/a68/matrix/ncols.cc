#include "matrix.ih"

size_t Matrix::nCols()
{
	return d_nCols;
}
